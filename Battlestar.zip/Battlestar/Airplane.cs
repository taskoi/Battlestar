﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Battlestar
{
    public class Airplane
    {
        

        public int X;
        public int Y;
        Airplane(int x, int y )
        {
            X = x;
            Y = y;       
        }

        

    }

}
